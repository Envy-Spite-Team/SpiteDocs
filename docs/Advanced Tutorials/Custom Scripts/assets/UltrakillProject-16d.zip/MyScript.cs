﻿using UnityEngine;

namespace $safeprojectname$
{
    public class MyScript : MonoBehaviour
    {

    }
}
